import requests
from datetime import datetime #For cleanDate Function
import numpy as np #for advance list operation used the data which were taken by webscraping method
import json
from bs4 import BeautifulSoup
import pandas as pd

consumer_key = "m20frh2KA7id8wYdPGLdwfdUt"
consumer_secret = "f0rviwv8UPmwdjMPEoSHAkbulPY9VvC0fKxjquv7OKZ1D3XXXI"

access_token = "217025602-w80ni21i7EaEcTICqSpWxmXr3jqWkNJJigrIQDxe"
access_token_secret = "Y6NVAJ6vDT4P931mDtKHY9Oo2Ghb0dZgbBqN7fusm8m0w"

def ScrapeTable():
    #We use Header because the website has asked for "User-Agent" parameter, if this is not written it says"403-Forbidden" hatası alınıyor
    #The solution came from this link:
    #https://stackoverflow.com/questions/38489386/python-requests-403-forbidden
    
    header = {"User-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36"}
    FridaysForFutureUrl = "https://map.fridaysforfuture.org/list-countries/"
    page = requests.get(FridaysForFutureUrl,headers=header)
    parsedPage = BeautifulSoup(page.content,"html.parser")
    rows = parsedPage.find_all("tr", limit = 6) 
    
    #create a empty list as titles
    titles = []
    #dtype -> datatype
    strikelist = np.zeros((19,4),dtype = np.int32) #the statistics from FFF have to be reload in a table
   

    for x in range(1,6): #1-6 was written because the number of rows that I was focusing on were 6 according to the URL
        cells = rows[x].find_all("td") #find td tag and put all of them into cells for the selected row
        for y in range(1,len(cells)): #iterate over all the cells in the row
            if(cells[y].get_text() != ''): #If the cell is not empty
                if(x == 1):#If this is the first row
                    titles.append(cells[y].get_text()) #Add the content of the cell to the titles list
                else:
                    #Subtract the first values of x and y in order to
                    #make the ls start from index (0,0)
                    strikelist[y-1,x-2] = int(cells[y].get_text()) #If this is not the first row, add the content of the cell to the strike list

    #DATA CLEANING PART               
    #Delete 17th column - data cleaning
    strikelist = np.delete(strikelist, 17, 0)
    dataDict = {}
    #Add Dates as keys and lists as values to the dictionary
    #len(strikelist) is 18
    for x in range(18):
        dataDict[str(cleanDate(titles[x],"FFF"))] = strikelist[x]  #DATA CLEANING PART    
        
    #Create a dataframe from the dictionary
    df = pd.DataFrame(data=dataDict)
    
    #Return the dataframe
    return df


def cleanDate(date, source = "twitter"):
    newDate = datetime(1970,1,1)
    if(source == "FFF"):
        #date format -> dd MMMYYYY 
        #convert formatted string to datetime
        newDate = datetime.strptime(date,"%d %b%Y ")
    else:
        # date format -> DDD MMM dd zzzz ZZZ YYYY
        seperatedDate = date.split()
        seperatedDate = seperatedDate[2] + " " + seperatedDate[1] + " " + seperatedDate[5]
        newDate = datetime.strptime(seperatedDate,"%d %b %Y")
    
    return newDate