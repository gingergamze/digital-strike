import dash
import dash_core_components as dcc
import dash_html_components as html
import plotly.express as px
import pandas as pd
import definitions as defi
import json


#Scrape the table from Fridays For Future and create a dataframe
table = defi.ScrapeTable()
head = table.columns

dates = []
#Take dates from the table
for x in range(len(head)):
    dates.append(head[x])


#Open the file that tweets were saved
with open("TweetswithHashtags.json", "r") as file:
    #Read the tweets
    tweetList = json.loads(file.read())

#Create initial dataframe
data = pd.DataFrame(data = {"Date":[],
                            "Fav":[],
                            "Retweet":[],
                            "hashtag_CSO_fav":[],
                            "hashtag_DS_fav":[],
                            "hashtag_DCS_fav":[],
                            "hashtag_CSO_rt":[],
                            "hashtag_DS_rt":[],
                            "hashtag_DCS_rt":[]})


#For each tweet in the file
for x in range(len(tweetList)-2):
    #Decide if the tweet is a retweet or a normal tweet by looking at the fav count
    #If the fav count is zero, the tweet is a retweet
    #Thus, the favorite_count information is under retweeted_status
    #Record The fav count of the tweet
    if(tweetList[x]["favorite_count"] == 0):
        fav = tweetList[x]["retweeted_status"]["favorite_count"]
    else:
        fav = tweetList[x]["favorite_count"]
        
    #Record the retweet count of the tweet
    rt = tweetList[x]["retweet_count"]
    
    #Record the tweet date 
    date = defi.cleanDate(tweetList[x]["created_at"])
    
    #Record the favorite counts of each hashtag seperately
    if("DigitalStrike" in tweetList[x]["full_text"]):
        hashtag_DS_fav = fav
        hashtag_DS_rt = rt
    else:
        hashtag_DS_fav = 0
        hashtag_DS_rt = 0
    if("ClimateStrikeOnline" in tweetList[x]["full_text"] ):
        hashtag_CSO_fav = fav
        hashtag_CSO_rt = rt
    else:
        hashtag_CSO_fav = 0
        hashtag_CSO_rt = 0
    if("DigitalClimateStrike" in tweetList[x]["full_text"]):
        hashtag_DCS_fav = fav
        hashtag_DCS_rt = rt
    else:
        hashtag_DCS_fav = 0
        hashtag_DCS_rt = 0
    
    #Create a dataframe with the recorded info
    tweetData = pd.DataFrame(data={"Date":[date],
                                   "Fav":[fav],
                                   "Retweet":[rt],
                                   "hashtag_CSO_fav":[hashtag_CSO_fav],
                                   "hashtag_DS_fav":[hashtag_DS_fav],
                                   "hashtag_DCS_fav":[hashtag_DCS_fav],
                                   "hashtag_CSO_rt":[hashtag_CSO_rt],
                                   "hashtag_DS_rt":[hashtag_DS_rt],
                                   "hashtag_DCS_rt":[hashtag_DCS_rt]})
    #Append the tweetData to original dataframe
    data = data.append(tweetData,ignore_index = True)


#Get the data ready for plotting
favCounts = data.groupby("Date").sum()["Fav"]
rtCounts = data.groupby("Date").sum()["Retweet"]

CSOFavCounts = data.groupby("Date").sum()["hashtag_CSO_fav"]
DSFavCounts = data.groupby("Date").sum()["hashtag_DS_fav"]
DCSFavCounts = data.groupby("Date").sum()["hashtag_DCS_fav"]

CSORtCounts = data.groupby("Date").sum()["hashtag_CSO_rt"]
DSRtCounts = data.groupby("Date").sum()["hashtag_DS_rt"]
DCSRtCounts = data.groupby("Date").sum()["hashtag_DCS_rt"]
                 



#Start the dash
prj = dash.Dash()


"""
Layout:
    Header
    
    Dropdown Box: There are 3 options, favorite count and retweet count
    has 3 radio button options for hashtag spesific data and the climate
    strikes option has 4 radio button options for each row from the table
    
"""
prj.layout = html.Div(children=[
    html.H1(id = "Header",
        children = "Statistics of Greta Thunberg's Tweets",
    style ={
        "textAlign" : "center",
        }),
    html.P("Tweets with hashtags #ClimateStrikeOnline, #DigitalStrike, #DigitalClimateStrike",
           style ={
                   "textAlign" : "center",
                   "color" : "red",
                   "fontFamily" : "courier"
               }
           
           ),
    html.Div(
        children = [
            dcc.Dropdown(  
                id="dropdown",
                options=[
                    {"label": "Favourite Count", "value": "fav"},
                    {"label": "Retweet Count", "value": "rt"},
                    {"label": "Climate Strikes", "value": "str"}
                ],
                value="fav"
            ),
            dcc.RadioItems(
                id="radio",
                options=[
                    {"label":"#ClimateStrikeOnline", "value":"ClimateStrikeOnline"},
                    {"label":"#DigitalStrike", "value":"DigitalStrike"},
                    {"label":"#DigitalClimateStrike", "value":"DigitalClimateStrike"},
                ],
                value = "ClimateStrikeOnline",
                labelStyle={
                            "display": "inline-block"
                            }
                
            )
            
        ]    
    ),
    dcc.Graph(
        id="graph"
        )
    ])


"""
    This callback function takes dropdown box value as input and
    changes the graph, header and the radio button actions accordingly
    Information from https://dash.plotly.com/basic-callbacks site was
    used while building this function
"""
@prj.callback(
    [
     dash.dependencies.Output("Header", "children"),
     dash.dependencies.Output("radio","options"),
     dash.dependencies.Output("radio","value")
     ],
    [dash.dependencies.Input("dropdown", "value")])
def update_output(value):
    #If "Favourite Count" has chosen in the dropdown box
    if (value == "fav"):
        header = "Fav Counts of Greta's Tweets"
        
        #Related radio button options
        options=[
                    {"label":"#ClimateStrikeOnline", "value":"ClimateStrikeOnline"},
                    {"label":"#DigitalStrike", "value":"DigitalStrike"},
                    {"label":"#DigitalClimateStrike", "value":"DigitalClimateStrike"},
                ]
        value = "ClimateStrikeOnline"
     
    #If "Retweet Count" has chosen in the dropdown box                      
    elif(value == "rt"):
        header = "Retweet Counts of Greta's Tweets"
        
        #Related radio button options
        options=[
                    {"label":"#ClimateStrikeOnline", "value":"ClimateStrikeOnline"},
                    {"label":"#DigitalStrike", "value":"DigitalStrike"},
                    {"label":"#DigitalClimateStrike", "value":"DigitalClimateStrike"},
                ]
        value = "ClimateStrikeOnline"
        
    #If "Climate Strikes" has chosen in the dropdown box  
    else:
        header = "Climate Strike Statistics from Fridays For Future"
        
        #Related radio button options
        options=[
                    {"label":"Countries", "value":"countries"},
                    {"label":"Cities", "value":"cities"},
                    {"label":"Events", "value":"events"},
                    {"label":"People", "value":"people"},
                ]
        value = "countries"
        
    #Change the webpage by returning the outputs
    return header, options, value


"""
    This callback function handles the radio buttons
"""
@prj.callback(
    dash.dependencies.Output("graph", "figure"),
    [dash.dependencies.Input("radio", "value"),
    dash.dependencies.Input("dropdown", "value")])
def radio_change(value, dropdownValue):
        #If "countries", "cities", "events" or "people" is selected it means
        #the "Climate Strikes" option is selected in the dropdown box
        #Plot the figures according to the selected radio button
        if(value == "countries"):
            #The "loc" function is returning the rows from the dataframe with given index
            fig = px.line( x = dates,y = table.loc[0])
        elif(value == "cities"):
            fig = px.line( x = dates,y = table.loc[1])
        elif(value == "events"):
            fig = px.line( x = dates,y = table.loc[2])
        elif(value == "people"):
            fig = px.line( x = dates,y = table.loc[3])
        
        #If "ClimateStrikeOnline", "DigitalStrike" or "DigitalClimateStrike"
        #is selected, check the dropdown box, if "Retweet Count" is selected
        #plot the graph using rt counts, if "Favorite Count" is selected
        #plot the graph using fav counts.
        elif(value == "ClimateStrikeOnline"):
            if(dropdownValue == "fav"):
                fig = px.line(CSOFavCounts)
            elif(dropdownValue == "rt"):
                fig = px.line(CSORtCounts)
        elif(value == "DigitalStrike"):
            if(dropdownValue == "fav"):
                fig = px.line(DSFavCounts)
            elif(dropdownValue == "rt"):
                fig = px.line(DSRtCounts)
        elif(value == "DigitalClimateStrike"):
            if(dropdownValue == "fav"):
                fig = px.line(DCSFavCounts)
            elif(dropdownValue == "rt"):
                fig = px.line(DCSRtCounts)
        else:
            fig = px.line(favCounts)
        return fig
    
    
    
if __name__ == '__main__':
    prj.run_server(debug=False)
    
    
    