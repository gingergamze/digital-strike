import definitions as defi
import tweepy
import datetime
import json



auth = tweepy.OAuthHandler(defi.consumer_key, defi.consumer_secret)
auth.set_access_token(defi.access_token, defi.access_token_secret)
api = tweepy.API(auth)

   
hashtags = ["#ClimateStrikeOnline","#DigitalStrike","#DigitalClimateStrike"]


with open("TweetswithHashtags.json", "w") as outfile:
    #First line of the JSON file
    outfile.write("[\n")
    
    #First 150 tweets to compare whether the given date is reached
    tweets = api.user_timeline(screen_name = "GretaThunberg",tweet_mode='extended',exclude_replies=True,count = 150)
    #Page number counter
    page = 1
    
    #While there are tweets to recieve
    while(tweets != []):
        for tweet in tweets:
            #Check if a tweet has any of the given hashtags
            #If it has, write it to file
            if any(tag in tweet._json["full_text"] for tag in hashtags):   
                json.dump(tweet._json, outfile, indent=2)
                outfile.write(",\n")
        #Retrieve new tweets
        tweets = api.user_timeline(screen_name = "GretaThunberg",tweet_mode='extended',exclude_replies=True,count = 150,page=page)
        #Increase the page counter
        page += 1
    #To get rid of the last extra comma and closing the bracket
    outfile.write("{}\n]")